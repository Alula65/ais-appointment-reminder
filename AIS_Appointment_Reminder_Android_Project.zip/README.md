# AIS Appointment Reminder (Android source)

A simple Android reminder app for manually checking Saron's AIS appointment.

## What it does
- Schedules a recurring reminder using Android WorkManager.
- Opens the official Ethiopia AIS portal from a notification or button.
- Stores a preferred target date locally on the phone.

## What it does NOT do
- It does not log in to AIS.
- It does not store AIS credentials.
- It does not scrape, poll, or monitor appointment availability.
- It does not reschedule or book appointments.

## Build and install
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle sync and install the Android SDK requested by the project.
4. Connect your Android phone with USB debugging enabled, or build an APK using Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the generated APK on your phone.
6. Open the app and allow notifications.
7. Tap **Turn on 30-minute reminders**.

## Timing note
Android WorkManager periodic tasks have a minimum interval of 15 minutes, but execution is inexact. Battery saver, Doze mode, and phone-maker background restrictions can delay reminders. It is not guaranteed to notify at exactly 30-minute intervals.

## Privacy
No network calls are made by the app. The saved target date remains in local app preferences.
