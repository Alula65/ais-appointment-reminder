package com.example.aisappointmentreminder

import android.Manifest
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.Calendar
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("appointment", MODE_PRIVATE) }
    private lateinit var dateLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        requestNotificationPermissionIfNeeded()

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(44, 56, 44, 40)
        }
        fun addText(text: String, size: Float = 16f): TextView {
            return TextView(this).also {
                it.text = text
                it.textSize = size
                it.setPadding(0, 0, 0, 24)
                layout.addView(it)
            }
        }
        addText("AIS Appointment Reminder", 24f)
        addText("Saron · F-1 · Addis Ababa")
        addText("Current appointment: February 9, 2027")
        addText("This app does not log in to AIS or check appointment slots. It reminds you to check the official portal yourself.")
        dateLabel = addText("Reminder target: ${prefs.getString("target_date", "Any date before February 9, 2027")}")
        val chooseDate = Button(this).apply {
            text = "Set preferred earliest date"
            setOnClickListener { showDatePicker() }
        }
        layout.addView(chooseDate)

        val start = Button(this).apply {
            text = "Turn on 30-minute reminders"
            setOnClickListener { scheduleReminders(); Toast.makeText(this@MainActivity, "30-minute reminders enabled", Toast.LENGTH_SHORT).show() }
        }
        layout.addView(start)

        val stop = Button(this).apply {
            text = "Turn reminders off"
            setOnClickListener {
                WorkManager.getInstance(this@MainActivity).cancelUniqueWork(REMINDER_WORK)
                Toast.makeText(this@MainActivity, "Reminders turned off", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(stop)

        val open = Button(this).apply {
            text = "Open official AIS appointment portal"
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://ais.usvisa-info.com/en-et/niv")))
            }
        }
        layout.addView(open)

        addText("Reminder checks are scheduled by Android and may be delayed by battery saver, Doze mode, or manufacturer background limits. Notifications require permission.")
        setContentView(layout)
    }

    private fun showDatePicker() {
        val c = Calendar.getInstance()
        DatePickerDialog(this, { _, year, month, day ->
            val value = "%04d-%02d-%02d".format(year, month + 1, day)
            prefs.edit().putString("target_date", value).apply()
            dateLabel.text = "Reminder target: $value"
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun scheduleReminders() {
        val request = PeriodicWorkRequestBuilder<ReminderWorker>(30, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            REMINDER_WORK, ExistingPeriodicWorkPolicy.UPDATE, request
        )
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = android.app.NotificationChannel(
                ReminderWorker.CHANNEL_ID, "AIS check reminders",
                android.app.NotificationManager.IMPORTANCE_DEFAULT
            )
            getSystemService(android.app.NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    companion object { const val REMINDER_WORK = "ais_check_reminder" }
}
