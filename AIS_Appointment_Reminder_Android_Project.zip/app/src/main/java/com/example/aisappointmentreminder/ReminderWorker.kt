package com.example.aisappointmentreminder

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.Worker
import androidx.work.WorkerParameters

class ReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://ais.usvisa-info.com/en-et/niv"))
        val pending = PendingIntent.getActivity(
            applicationContext, 10, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Check Saron's F-1 appointment")
            .setContentText("Look for an earlier Addis Ababa interview date in AIS.")
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        return try {
            NotificationManagerCompat.from(applicationContext).notify(3001, notification)
            Result.success()
        } catch (_: SecurityException) {
            Result.success()
        }
    }

    companion object { const val CHANNEL_ID = "ais_reminder_channel" }
}
